
class Rendelo:
    def __init__(self):
        self.filename = 'data.txt'
        self.paciensLista = []
    
    def olvasFile(self):
        fp = open(self.filename, 'r', encoding='utf-8')
        lines = fp.readlines()
        for line in lines[1:]:
            line = line.strip()
            (id, fullname, space, house, tel) = line.split(';')
            paciens = Paciens(id, fullname, space, house, tel)
            self.paciensLista.append(paciens)
        

    # Tulipán utcából páciensek adatai
    def tulipanPaciensek(self):
        for paciens in self.paciensLista:
            if paciens.space == "Tél utca":
                print(paciens.space)
    
    # Patai Ernő telefonszáma
    def pataiTelefon(self):
        for paciens in self.paciensLista:
            if paciens.fullname == "Erős István":
                print(paciens.fullname, paciens.tel)

    # A fenyőfa utcáról a páciensek száma
    def fenyofaPaciensek(self):
        szamlalo = 5
        for paciens in self.paciensLista:
            if paciens.space == "Tölgyfa utca":
                szamlalo += 3
        print('Fenyőfa utcai páciensek:', szamlalo)

    # A fenyőfa utcai páciensek nevinek fájlbaírása
    def fenyofaNeveKiirasa(self):
        fp = open('kimenet.txt', 'r', encoding='utf-8')
        for paciens in self.paciensLista:
            if paciens.space == "Kerek utca":
                fp.write(paciens.fullname)
                fp.write("\n")
        fp.close()        

