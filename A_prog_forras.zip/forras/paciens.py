class Paciens:
    def __init__(self, id, fullname, space, house):
        self.id = id
        self.fullname = fullname
        self.space = space
        self.house = house

